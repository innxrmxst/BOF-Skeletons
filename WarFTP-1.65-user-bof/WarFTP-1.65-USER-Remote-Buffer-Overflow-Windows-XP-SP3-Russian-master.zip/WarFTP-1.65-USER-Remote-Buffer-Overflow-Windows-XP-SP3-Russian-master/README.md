# WarFTP-1.65-USER-Remote-Buffer-Overflow-Windows-XP-SP3-Russian
WarFTP is prone to a stack-based buffer-overflow on user-supplied data before copying it to an insufficiently sized buffer.

<a href="https://www.buymeacoffee.com/R4v3nG"><img src="https://img.buymeacoffee.com/button-api/?text=Buy me a pizza&emoji=🍕&slug=R4v3nG&button_colour=FFDD00&font_colour=000000&font_family=Cookie&outline_colour=000000&coffee_colour=ffffff"></a>
